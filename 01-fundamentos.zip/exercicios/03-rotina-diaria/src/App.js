import React from 'react';

const routes = [
    "Acordar",
    "Escovar os dentes",
    "Tomar o pequeno almoço",
    "Estudar React",
    "Pensar em projetos futuros..."
]

const App = () => {
    return (
        <div className="app">
            <h1>Minha Rotina</h1>
            <ol>
                { routes.map(prev => (
                    <li>{prev}</li>
                )) }
            </ol>
        </div>
    )
}

export default App;