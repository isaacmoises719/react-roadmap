import React from 'react';
import './App.css';
const img = './assets/products.png'

const App = () => {
    return (
        <div className="app">
            <div className="image-area">
                <img src={img} alt="Produtos"/>
            </div>
            <div className="text-area">
                <h1>Os melhores produtos com os melhores preços!</h1>
            </div>
        </div>
    )
}

export default App;